# Preview all emails at http://localhost:3000/rails/mailers/looper
class LooperPreview < ActionMailer::Preview

end
