require 'test_helper'

class LooperTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
