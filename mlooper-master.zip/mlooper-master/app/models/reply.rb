class Reply < ActiveRecord::Base
end
